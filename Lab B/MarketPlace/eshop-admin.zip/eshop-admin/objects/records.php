<?php
class Products{
 
    // database connection and table name
    private $conn;
    private $table_name = "products";
 
    // object properties
    public $Productid;
    public $Name;
    public $Category;
    public $Image;
    public $date_added;
    public $Discount;
    public $featured_id;
    public $officialSite;
    public $productDescription;
    public $validity;
    public $status_id;
 
    public function __construct($db){
        $this->conn = $db;
    }
 
    // create records
    function create(){
 
        //write query
        $query = "INSERT INTO " . $this->table_name . "
            SET Category=:Category, Name=:Name, Image=:Image, date_added=:date_added,
                Discount=:Discount, featured_id=:featured_id, officialSite=:officialSite, productDescription=:productDescription,
                validity=:validity, status_id=:status_id";
 
        $stmt = $this->conn->prepare($query);
 
        // posted values
        $this->Category=htmlspecialchars(strip_tags($this->Category));
        $this->Name=htmlspecialchars(strip_tags($this->Name));
        $this->Image=htmlspecialchars(strip_tags($this->Image));
        $this->Discount=htmlspecialchars(strip_tags($this->Discount));
        $this->featured_id=htmlspecialchars(strip_tags($this->featured_id));
        $this->officialSite=htmlspecialchars(strip_tags($this->officialSite));
        $this->productDescription=htmlspecialchars(strip_tags($this->productDescription));
        $this->validity=htmlspecialchars(strip_tags($this->validity));
        $this->status_id=htmlspecialchars(strip_tags($this->status_id));
 
        // to get time-stamp for 'created' field
        $this->timestamp = date('Y-m-d H:i:s');
 
        // bind values 
        $stmt->bindParam(":Category", $this->Category);
        $stmt->bindParam(":Name", $this->Name);
        $stmt->bindParam(":Image", $this->Image);
        $stmt->bindParam(":Discount", $this->Discount);
        $stmt->bindParam(":featured_id", $this->featured_id);
        $stmt->bindParam(":officialSite", $this->officialSite);
        $stmt->bindParam(":productDescription", $this->productDescription);
        $stmt->bindParam(":validity", $this->validity);
        $stmt->bindParam(":status_id", $this->status_id);
        $stmt->bindParam(":date_added", $this->timestamp);
 
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
 
    }
    // used for paging records
public function countAll(){
 
    $query = "SELECT Productid FROM " . $this->table_name . "";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    $num = $stmt->rowCount();
 
    return $num;
}
   function readAll($from_record_num, $records_per_page){
 
    $query = "SELECT Productid, Name, Category, Discount, validity, status_id FROM " . $this->table_name . "
            ORDER BY
                Productid ASC
            LIMIT
                {$from_record_num}, {$records_per_page}";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    return $stmt;
}
function readOne(){
 
    $query = "SELECT Category, Name, Image, Discount, featured_id, officialSite, productDescription, validity, status_id FROM " . $this->table_name . "
            WHERE
                Productid = ?
            LIMIT
                0,1";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->bindParam(1, $this->Productid);
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
 
    $this->Category = $row['Category'];
    $this->Name = $row['Name'];
    $this->Image = $row['Image'];
    $this->Discount = $row['Discount'];
    $this->featured_id = $row['featured_id'];
    $this->officialSite = $row['officialSite'];
    $this->productDescription = $row['productDescription'];
    $this->validity = $row['validity'];
    $this->status_id = $row['status_id'];
}
function update(){
 
    $query = "UPDATE " . $this->table_name . "
            SET
                Category = :Category,
                Name = :Name,
                Discount = :Discount,
                featured_id = :featured_id,
                officialSite = :officialSite,
                productDescription = :productDescription,
                validity = :validity,
                status_id  = :status_id
            WHERE
                Productid = :Productid";
 
    $stmt = $this->conn->prepare($query);
 
    // posted values
    $this->Category=htmlspecialchars(strip_tags($this->Category));
    $this->Name=htmlspecialchars(strip_tags($this->Name));
    $this->Discount=htmlspecialchars(strip_tags($this->Discount));
    $this->featured_id=htmlspecialchars(strip_tags($this->featured_id));
    $this->officialSite=htmlspecialchars(strip_tags($this->officialSite));
    $this->productDescription=htmlspecialchars(strip_tags($this->productDescription));
    $this->validity=htmlspecialchars(strip_tags($this->validity));
    $this->status_id=htmlspecialchars(strip_tags($this->status_id));
    $this->Productid=htmlspecialchars(strip_tags($this->Productid));
 
    // bind parameters
    $stmt->bindParam(':Category', $this->Category);
    $stmt->bindParam(':Name', $this->Name);
    $stmt->bindParam(':Discount', $this->Discount);
    $stmt->bindParam(':featured_id', $this->featured_id);
    $stmt->bindParam(':officialSite', $this->officialSite);
    $stmt->bindParam(':productDescription', $this->productDescription);
    $stmt->bindParam(':validity', $this->validity);
    $stmt->bindParam(':status_id', $this->status_id);
    $stmt->bindParam(':Productid', $this->Productid);
 
    // execute the query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
// delete the record
function delete(){
 
    $query = "DELETE FROM " . $this->table_name . " WHERE Productid = ?";
     
    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->Productid);
 
    if($result = $stmt->execute()){
        return true;
    }else{
        return false;
    }
}
// will upload image file to server
function uploadPhoto(){
 
    $result_message="";
 
    // now, if image is not empty, try to upload the image
    if($this->Image){
 
        // sha1_file() function is used to make a unique file name
        $target_directory = "uploads/";
        $target_file = $target_directory . $this->Image;
        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
 
        // error message is empty
        $file_upload_error_messages="";

        // make sure that file is a real image
$check = getimagesize($_FILES["image"]["tmp_name"]);
if($check!==false){
    // submitted file is an image
}else{
    $file_upload_error_messages.="<div>Submitted file is not an image.</div>";
}
 
// make sure certain file types are allowed
$allowed_file_types=array("jpeg", "png");
if(!in_array($file_type, $allowed_file_types)){
    $file_upload_error_messages.="<div>Only JPEG and PNG files are allowed.</div>";
}
 
// make sure file does not exist
if(file_exists($target_file)){
    $file_upload_error_messages.="<div>The merchant's logo already exists. Try to change image name.</div>";
}
 
// make sure submitted file is not too large, can't be larger than 1 MB
if($_FILES['image']['size'] > (1024000)){
    $file_upload_error_messages.="<div>Image must be less than 1 MB in size.</div>";
}
 
// make sure the 'uploads' folder exists
// if not, create it
if(!is_dir($target_directory)){
    mkdir($target_directory, 0777, true);
}

// if $file_upload_error_messages is still empty
if(empty($file_upload_error_messages)){
    // it means there are no errors, so try to upload the file
    if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
        // it means photo was uploaded
    }else{
        $result_message.="<div class='alert alert-danger'>";
            $result_message.="<div>Unable to upload logo.</div>";
            $result_message.="<div>Update the merchant to upload logo.</div>";
        $result_message.="</div>";
    }
}
 
// if $file_upload_error_messages is NOT empty
else{
    // it means there are some errors, so show them to user
    $result_message.="<div class='alert alert-danger'>";
        $result_message.="{$file_upload_error_messages}";
        $result_message.="<div>Update the merchant to upload logo.</div>";
    $result_message.="</div>";
}
 
    }
 
    return $result_message;
}
function readActive(){
 
    $query = "SELECT Category, Name, Discount, officialSite, productDescription, validity, status_id FROM " . $this->table_name . "
            WHERE 
                status_id = 2
            ORDER BY
                Productid ASC";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->execute();
 
    return $stmt;
}
}
?>