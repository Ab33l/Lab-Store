<?php
class Category{
 
    // database connection and table name
    private $conn;
    private $table_name = "category";
 
    // object properties
    public $id;
    public $category;
 
    public function __construct($db){
        $this->conn = $db;
    }

    // used by select drop-down list
    function read(){
        //select all data
        $query = "SELECT
                    Categoryid, Name
                FROM
                    " . $this->table_name . "
                ORDER BY
                    Name";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
 
        return $stmt;
    }
    // used to read status name by its ID
    function readChildName(){
     
    $query = "SELECT name FROM " . $this->table_name . " WHERE Categoryid = ? limit 0,1";
 
    $stmt = $this->conn->prepare( $query );
    $stmt->bindParam(1, $this->id);
    $stmt->execute();
 
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
    $this->name = $row['name'];
}

    function readParentChildName(){
        $query = "SELECT p.Categoryid AS 'pCategoryid', p.Name AS 'Parent', c.Categoryid AS 'cCategoryid', c.Name AS 'Child' FROM " . $this->table_name . " c INNER JOIN Category p ON c.Parent = p.Categoryid WHERE c.Categoryid = ?";

        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
     
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $this->Parent = $row['Parent'];
        $this->Child = $row['Child'];
    }

    // used by select drop-down list
    function readChild(){
        //select all data
        $query = "SELECT
                    *
                FROM
                    " . $this->table_name . "
                WHERE Parent != 0
                ORDER BY
                    Name";  
 
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
 
        return $stmt;
    }
}
?>