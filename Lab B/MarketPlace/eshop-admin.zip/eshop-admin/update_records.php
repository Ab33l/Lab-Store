<?php
// get ID of the record to be read
$records_id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');

// set page header
$page_title = "Update Records";
include_once "layout_header.php";
// get ID of the record to be edited
$Productid = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
 
// include database and object files
include_once 'connect.php';
include_once 'objects/records.php';
include_once 'objects/status.php';
include_once 'objects/featured.php';
include_once 'objects/category.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare objects
$records = new Products($db);
$status = new Status($db);
$featured = new Featured($db);
$category = new Category($db);
 
// set ID property of record to be edited
$records->Productidid = $Productid;

// read the details of record to be read
$records->Productid = $records_id;
// read the details of record to be edited
$records->readOne();
 
?>

<?php 
// if the form was submitted
if($_POST){
 
    // set record property values
    $records->Name = $_POST['Name'];
    $records->Category = $_POST['Category'];
    $records->Discount = $_POST['Discount'];
    $records->marks = $_POST['marks'];
    $records->status_id = $_POST['status_id'];
 
    // update the record
    if($records->update()){
        echo "<div class='alert alert-success alert-dismissable'>";
            echo "Merchant Record was updated.";
        echo "</div>";
    }
 
    // if unable to update the record, tell the user
    else{
        echo "<div class='alert alert-danger alert-dismissable'>";
            echo "Unable to update record.";
        echo "</div>";
    }
}
?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id={$records_id}");?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
 
        <tr>
            <td>Merchant Name</td>
            <td><input type='text' name='Name' value='<?php echo $records->Name;?>' class='form-control' /></td>
        </tr>

        <tr>
            <td>Category</td>
            <td>
                <?php
               $stmt = $category->read();
 
             // put them in a select drop-down
             echo "<select class='form-control' name='Category'>";
 
             echo "<option>Please select...</option>";
            while ($row_status = $stmt->fetch(PDO::FETCH_ASSOC)){
            $Category=$row_status['Categoryid'];
            $Category_name = $row_status['Name'];
 
            // current status of the record must be selected
            if($records->Category==$Category){
            echo "<option value='$Category' selected>";
            }else{
            echo "<option value='$Category_id'>";
            }
 
            echo "$Category_name</option>";
            }
            echo "</select>";
            ?>
            </td>
        </tr>

        <tr>
            <td>Maximum Discount</td>
            <td><input type='text' name='email_address' value='<?php echo $records->Discount; ?>%' class='form-control' /></td>
        </tr>

        <tr>
            <td>Featured</td>
            <td>
                <?php
               $stmt = $featured->read();
 
             // put them in a select drop-down
             echo "<select class='form-control' name='featured'>";
 
             echo "<option>Please select...</option>";
            while ($row_status = $stmt->fetch(PDO::FETCH_ASSOC)){
            $featured_id=$row_status['id'];
            $featured = $row_status['featured'];
 
            // current status of the record must be selected
            if($records->featured_id==$featured_id){
            echo "<option value='$featured_id' selected>";
            }else{
            echo "<option value='$featured_id'>";
            }
 
            echo "$featured</option>";
            }
            echo "</select>";
            ?>
            </td>
        </tr>
 
        <tr>
            <td>Official Website</td>
            <td><input type='text' name='marks' value='<?php echo $records->officialSite; ?>' class='form-control' /></td>
        </tr>

        <tr>
            <td>Validity Period</td>
            <td><input type='text' name='validity' value='<?php echo $records->validity; ?>' class='form-control' /></td>
        </tr>

        <tr>
            <td>Merchant Product Description</td>
            <td>
            <textarea class="form-control" placeholder="Leave a comment here"
            id="floatingTextarea" style="height: 150px;" name="productDescription"><?php echo $records->productDescription; ?></textarea>                
            </td>
        </tr>

        <tr>
            <td>Status</td>
            <td>
                <?php
               $stmt = $status->read();
 
             // put them in a select drop-down
             echo "<select class='form-control' name='status_id'>";
 
             echo "<option>Please select...</option>";
            while ($row_status = $stmt->fetch(PDO::FETCH_ASSOC)){
            $status_id=$row_status['id'];
            $status_name = $row_status['status'];
 
            // current status of the record must be selected
            if($records->status_id==$status_id){
            echo "<option value='$status_id' selected>";
            }else{
            echo "<option value='$status_id'>";
            }
 
            echo "$status_name</option>";
            }
            echo "</select>";
            ?>
            </td>
        </tr>

        <tr>
            <td>Merchant Logo</td>
            <td>
            <?php echo $records->Image ? "<img src='uploads/{$records->Image}' style='width:400px;height:400px;' />" : "No image found."; ?>
            <input type="file" name="image" />
            </td>
        </tr>
 
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Update</button>
            </td>
        </tr>
 
    </table>
</form>

<?php
 
// set page footer
include_once "layout_footer.php";
?>