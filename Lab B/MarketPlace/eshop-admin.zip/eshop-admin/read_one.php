<?php
// get ID of the record to be read
$records_id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
 
// include database and object files
include_once 'connect.php';
include_once 'objects/records.php';
include_once 'objects/status.php';
include_once 'objects/featured.php';
include_once 'objects/category.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare objects
$records = new Products($db);
$status = new Status($db);
$featured = new Featured($db);
$category = new Category($db);
 
// set ID property of record to be read
$records->records_id = $records_id;
 
// read the details of record to be read
$records->Productid = $records_id;
$records->readOne();
// set page headers
$page_title = "View a Single Merchant";
include_once "layout_header.php";
 
// read records button
echo "<div class='right-button-margin'>";
    echo "<a href='index.php' class='btn btn-primary pull-right'>";
        echo "<span class='glyphicon glyphicon-list'></span> Read Records";
    echo "</a>";
echo "</div>";
$prodDesc = $records->productDescription;
$prodConv = nl2br(htmlspecialchars($prodDesc));
// HTML table for displaying a record details
echo "<table class='table table-hover table-responsive table-bordered'>";
 
    echo "<tr>";
        echo "<td>Merchant Name</td>";
        echo "<td>{$records->Name}</td>";
    echo "</tr>";

    echo "<tr>";
        echo "<td>Category</td>";
        echo "<td>";
            // display status
            $category->id=$records->Category;
            $category->readParentChildName();
            echo $category->Parent . '  ~  ' . $category->Child;
        echo "</td>";
    echo "</tr>";
    
    echo "<tr>";
        echo "<td>Maximum Discount</td>";
        echo "<td>{$records->Discount}%</td>";
    echo "</tr>";
 
    echo "<tr>";
        echo "<td>Official Website</td>";
        echo "<td>{$records->officialSite}</td>";
    echo "</tr>";
 
    echo "<tr>";
        echo "<td>Product Description</td>";
        echo "<td>{$prodConv}</td>";
    echo "</tr>";

    echo "<tr>";
        echo "<td>Validity</td>";
        echo "<td>{$records->validity}</td>";
    echo "</tr>";
    
    echo "<tr>";
        echo "<td>Featured</td>";
        echo "<td>";
            // display status
            $featured->id=$records->featured_id;
            $featured->readName();
            echo $featured->name;
        echo "</td>";
    echo "</tr>";

    echo "<tr>";
        echo "<td>Status</td>";
        echo "<td>";
            // display status
            $status->id=$records->status_id;
            $status->readName();
            echo $status->name;
        echo "</td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>Merchant Logo</td>";
    echo "<td>";
        echo $records->Image ? "<img src='uploads/{$records->Image}' style='width:400px;height:400px;' />" : "No image found.";
    echo "</td>";
    echo "</tr>";
 
echo "</table>";
 
// set footer
include_once "layout_footer.php";
?>