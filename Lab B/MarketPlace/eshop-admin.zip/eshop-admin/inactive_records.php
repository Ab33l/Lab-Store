<?php 
// include database and object files
include_once 'connect.php';
include_once 'objects/records.php';
include_once 'objects/status.php';
 
// instantiate database and objects
$database = new Database();
$db = $database->getConnection();
 
$records = new Products($db);
$status = new Status($db);
 
// query records
$stmt = $records->readActive();
$num = $stmt->rowCount();
// set page header
$page_title = "Dormant Merchants";
include_once "layout_header.php";

if($num>0){
 
    echo "<table class='table table-hover table-responsive table-bordered'>";
        echo "<tr>";
            echo "<th>Merchant Name</th>";
            echo "<th>Category</th>";
            echo "<th>Max. Discount</th>";
            echo "<th>Validity</th>";
            echo "<th>Status</th>";
        echo "</tr>";
 
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
 
            extract($row);
 
            echo "<tr>";
                echo "<td>{$Name}</td>";
                echo "<td>{$Category}</td>";
                echo "<td>{$Discount}</td>";
                echo "<td>{$validity}</td>";
                echo "<td>";
                    $status->id = $status_id;
                    $status->readName();
                    echo $status->name;
                echo "</td>";
 
            echo "</tr>";
 
        }
 
    echo "</table>";
 
    // paging buttons will be here
    // the page where this paging is used
$page_url = "index.php?";
}
 
// tell the user there are no records
else{
    echo "<div class='alert alert-info'>No records found.</div>";
}
 
// set page footer
include_once "layout_footer.php";
?>