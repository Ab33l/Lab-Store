<?php
// include database and object files
include_once 'connect.php';
include_once 'objects/records.php';
include_once 'objects/status.php';
include_once 'objects/featured.php';
include_once 'objects/category.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();

// pass connection to objects
$records = new Products($db);
$status = new Status($db);
$featured = new Featured($db);
$category = new Category($db);
// set page headers
$page_title = "Create New Merchant";
include_once "layout_header.php";
 
?>
<?php 
if($_POST){
 
    // set records property values
    $records->Name = $_POST['Name'];
    $records->Category = $_POST['Category'];
    $records->officialSite = $_POST['officialSite'];
    $records->Discount = $_POST['Discount'];
    $records->featured_id = $_POST['featured_id'];
    $records->productDescription = $_POST['productDescription'];
    $records->validity = $_POST['validity'];
    $records->status_id = $_POST['status_id'];
    $Image=!empty($_FILES["image"]["name"])
        ? sha1_file($_FILES['image']['tmp_name']) . "-" . basename($_FILES["image"]["name"]) : "";
    $records->Image = $Image;
 
    // create the record
    if($records->create()){
        echo "<div class='alert alert-success'>The Merchant has been created.</div>";
        // try to upload the submitted file
        // uploadPhoto() method will return an error message, if any.
        echo $records->uploadPhoto();
    }
 
    // if unable to create the record, tell the user
    else{
        echo "<div class='alert alert-danger'>Unable to create new Merchant.</div>";
    }
}
?>
 
<!-- HTML form for creating a record -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">
 
    <table class='table table-hover table-responsive table-bordered'>
 
        <tr>
            <td>Merchant Name</td>
            <td><input type='text' name='Name' class='form-control' /></td>
        </tr>

        <tr>
            <td>Maximum Discount Amount</td>
            <td><input type='number' name='Discount' class='form-control' min=0 /></td>
        </tr>

        <tr>
            <td>Category</td>
            <td>
            <?php
            // read the record categories from the database
            $stmt = $category->readChild();
 
            // put them in a select drop-down
            echo "<select class='form-control' name='Category'>";
            echo "<option>Select Category...</option>";
 
            while ($row_status = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row_status);
            echo "<option value='{$Categoryid}'>{$Name}</option>";
            }
 
            echo "</select>";
            ?>
            </td>

        </tr>

 
        <tr>
            <td>Official Merchant Website</td>
            <td><input type='text' name='officialSite' class='form-control' /></td>
        </tr>

        <tr>
            <td>Merchant Product Description</td>
            <td><textarea class="form-control" placeholder="Merchant Product Description" id="floatingTextarea" style="height: 150px;" name="productDescription"></textarea></td>
        </tr>

        <tr>
            <td>Featured</td>
            <td>
            <?php
            // read the record categories from the database
            $stmt = $featured->read();
 
            // put them in a select drop-down
            echo "<select class='form-control' name='featured_id'>";
            echo "<option>Select Featured Status...</option>";
 
            while ($row_status = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row_status);
            echo "<option value='{$id}'>{$featured}</option>";
            }
 
            echo "</select>";
            ?>
            </td>
        </tr>

        <tr>
            <td>Maximum Product Validity Date</td>
            <td><input type='text' name='validity' class='form-control' /></td>
        </tr>
 
        <tr>
            <td>Merchant Status</td>
            <td>
            <?php
            // read the record categories from the database
            $stmt = $status->read();
 
            // put them in a select drop-down
            echo "<select class='form-control' name='status_id'>";
            echo "<option>Select Merchant Status...</option>";
 
            while ($row_status = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row_status);
            echo "<option value='{$id}'>{$status}</option>";
            }
 
            echo "</select>";
            ?>
            </td>
        </tr>
         
         <tr>
         <td>Merchant Logo</td>
         <td><input type="file" name="image" /></td>
         </tr>

        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Create</button>
            </td>
        </tr>
 
    </table>
</form>
<?php
 
// footer
include_once "layout_footer.php";
?>