<?php
// check if value was posted
if($_POST){
 
    // include database and object file
    include_once 'connect.php';
    include_once 'objects/records.php';
 
    // get database connection
    $database = new Database();
    $db = $database->getConnection();
 
    // prepare object
    $records = new Products($db);
     
    // set record id to be deleted
    $records->Productid = $_POST['Productid'];

     
    // delete the record
    if($records->delete()){
        echo "Merchant Record has been deleted.";
    }
     
    // if unable to delete the record
    else{
        echo "Unable to delete Merchant Record.";
    }
}
?>