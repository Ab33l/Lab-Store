<?php
session_start();
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /eshop-admin/signin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Absa eShop - Admin</title>
    <link rel="icon" type="image/png" href="images/absa-logo-red.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 
    <title><?php echo $page_title; ?></title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
  
    <!-- our custom CSS -->
    <link rel="stylesheet" href="custom.css" />
    <style>
    .navbar-nav {
    float: right;
    margin-right: 24px;
}
.navbar{
   background-image: linear-gradient(-140deg, #f78102 25%, #f70202 70%);
   -webkit-box-shadow: -3px 13px 24px -1px rgba(0,0,0,0.3);
   box-shadow: -3px 13px 24px -1px rgba(0,0,0,0.3);
}
.navbar > .container .navbar-brand, .navbar > .container-fluid .navbar-brand {
    margin-left: -15px;
    color: white;
}
.navbar-default .navbar-nav > li > a {
    color: white;
}

  </style>
</head>
<body>
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Absa eShop Admin</a>
    </div>
    <ul class="nav navbar-nav">
   <li><a href='index.php'>Manage Merchants</a></li>
   <li><a href='create_records.php'>Add Merchant</a></li>
   <!--<li><a href='managecategory.php'>Manage Merchant Categories</a></li>-->
   <li><a href='inactive_records.php'>Inactive Merchants</a></li>
   <li><a href="/eshop-admin/signout.php">Log Out</a></li>
    </ul>
  </div>
</nav>
    <!-- container -->
    <div class="container">
 
        <?php
        // show page header
        echo "<div class='page-header'>
                <h1>{$page_title}</h1>
            </div>";
        ?>